/****************************************************************************************
// Name: Khoa Phan
// Date: February 28, 2017
// Description: This program is written to get the standard deviation, using a math
//				formula, for the scores from an array of pointers to the Student class.
*****************************************************************************************/
#include <iostream>
#include <string>
#include "Student.hpp"
#include <cmath>

using std::cout;
using std::cin;
using std::endl;

//Function prototype
double stdDev(Student *, int);

//int main()
//{
//	const int SIZE = 4;
//	Student sArr[SIZE] = {
//		Student("Kai", 90),
//		Student("Bear", 88),
//		Student("Linda", 99),
//		Student("Mike", 95) };
//	double mySd;
//		
//	/*Student *myArr[SIZE];
//	for (int i = 0; i < SIZE; i++)
//	{
//		myArr[i] = &sArr[i];
//	}
//
//	mySd = stdDev(sArr, SIZE);
//
//	cout << mySd << endl;*/
//	return 0;
//}

double stdDev(Student *n, int s)
{
	Student *temp;
	double 
		results, total, mean2;
	double
		score, mean, diff, tempNum;

	results = total = mean2 = 0;
	
	// Retrieve scores from Student, add together
	for (int i = 0; i < s; i++)
	{	
		temp = (n + i);
		score = temp->getScore();
		total += score;
	}
	// Mean of Student scores
	mean = total / s;

	// Squares mean, gets mean2
	for (int i = 0; i < s; i++)
	{
		temp = (n + i);
		score = temp->getScore();
		diff = score - mean;
		tempNum = pow(diff, 2);
		mean2 += tempNum;
	}
	
	// Take square root of mean2
		results = sqrt(mean2);
		//cout << "Results " << results << endl;

	return results;
}